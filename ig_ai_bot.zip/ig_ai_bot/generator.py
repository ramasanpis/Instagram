import requests
from urllib.parse import quote_plus
from config import Config
from logger_config import logger

def generate_image_pollinations(prompt: str) -> str:
    base = Config.POLLINATIONS_BASE_URL.rstrip("/")
    url = f"{base}/{quote_plus(prompt)}"
    logger.info(f"Requesting image with prompt: {prompt}")
    resp = requests.get(url, allow_redirects=True, timeout=60)
    if resp.status_code != 200:
        logger.error(f"Image generation failed: {resp.status_code} {resp.text}")
        raise RuntimeError("Image generation failed.")
    final_url = resp.url
    logger.info(f"Got image URL: {final_url}")
    return final_url

def generate_caption_openrouter(prompt: str, max_tokens:int=60) -> str:
    api_key = Config.OPENROUTER_API_KEY
    api_url = Config.OPENROUTER_API_URL
    if not api_key or not api_url:
        logger.warning("OpenRouter API not configured; using fallback caption.")
        return f"{prompt} — AI generated."

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    data = {
        "model": "gpt-4o-mini",
        "prompt": f"Write a short Instagram caption/title (one or two lines) for the image described as: {prompt}",
        "max_tokens": max_tokens,
        "temperature": 0.9
    }
    try:
        r = requests.post(api_url, headers=headers, json=data, timeout=20)
        r.raise_for_status()
        j = r.json()
        if "choices" in j and len(j["choices"])>0:
            c = j["choices"][0]
            text = c.get("text") or (c.get("message") and c["message"].get("content")) or ""
            return text.strip()
        return j.get("output", "").strip() or f"{prompt} — AI generated."
    except Exception:
        logger.exception("Caption generation failed, using fallback.")
        return f"{prompt} — AI generated."
