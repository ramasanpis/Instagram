from instagrapi import Client
from config import Config
from logger_config import logger
import io
import requests
from PIL import Image

class InstagramClient:
    def __init__(self):
        self.client = Client()
        self.username = Config.INSTAGRAM_USERNAME
        self.password = Config.INSTAGRAM_PASSWORD
        self.logged_in = False

    def login(self):
        if not self.username or not self.password:
            raise RuntimeError("Instagram credentials not set in environment.")
        try:
            logger.info("Logging into Instagram...")
            self.client.login(self.username, self.password)
            self.logged_in = True
            logger.info("Logged in to Instagram.")
        except Exception:
            logger.exception("Instagram login failed.")
            raise

    def upload_image_url(self, image_url: str, caption: str) -> dict:
        if not self.logged_in:
            self.login()
        logger.info(f"Downloading image for upload: {image_url}")
        r = requests.get(image_url, timeout=30)
        r.raise_for_status()
        img = Image.open(io.BytesIO(r.content)).convert("RGB")
        buf = io.BytesIO()
        img.save(buf, format="JPEG")
        buf.seek(0)
        try:
            res = self.client.photo_upload(buf, caption)
            logger.info("Image uploaded successfully.")
            return res
        except Exception:
            logger.exception("Upload failed.")
            raise
