import sqlite3
from typing import Optional, Dict, Any

DB_PATH = "posts_queue.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            image_url TEXT,
            caption TEXT,
            status TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

def add_post(image_url: str, caption: str, status: str = "queued"):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO posts (image_url, caption, status) VALUES (?, ?, ?)",
              (image_url, caption, status))
    conn.commit()
    rowid = c.lastrowid
    conn.close()
    return rowid

def get_next_approved() -> Optional[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, image_url, caption FROM posts WHERE status='approved' ORDER BY created_at LIMIT 1")
    row = c.fetchone()
    conn.close()
    if not row:
        return None
    return {"id": row[0], "image_url": row[1], "caption": row[2]}

def list_posts():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, image_url, caption, status, created_at FROM posts ORDER BY created_at DESC")
    rows = c.fetchall()
    conn.close()
    return rows

def update_status(post_id:int, status:str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE posts SET status=? WHERE id=?", (status, post_id))
    conn.commit()
    conn.close()
