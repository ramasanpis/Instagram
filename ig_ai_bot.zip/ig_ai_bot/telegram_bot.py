import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, CallbackQueryHandler
from config import Config
from logger_config import logger
from generator import generate_image_pollinations, generate_caption_openrouter
from queue_db import add_post, list_posts, update_status, get_next_approved
from instagram_client import InstagramClient
import asyncio

class IGBot:
    def __init__(self):
        if not Config.TELEGRAM_BOT_TOKEN:
            raise RuntimeError("Telegram token not set.")
        self.app = ApplicationBuilder().token(Config.TELEGRAM_BOT_TOKEN).build()
        self.instagram = InstagramClient()
        self.auto_task = None
        self.setup_handlers()

    def setup_handlers(self):
        self.app.add_handler(CommandHandler("start", self.cmd_start))
        self.app.add_handler(CommandHandler("status", self.cmd_status))
        self.app.add_handler(CommandHandler("generate", self.cmd_generate))
        self.app.add_handler(CommandHandler("list", self.cmd_list))
        self.app.add_handler(CommandHandler("postnow", self.cmd_postnow))
        self.app.add_handler(CommandHandler("startbot", self.cmd_startbot))
        self.app.add_handler(CommandHandler("stopbot", self.cmd_stopbot))
        self.app.add_handler(CallbackQueryHandler(self.callback_query))

    async def cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text("Hello! I control the AI→Instagram bot.\nCommands: /generate, /list, /postnow, /startbot, /stopbot, /status")

    async def cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        mode = Config.POST_MODE
        rows = list_posts()
        queued = sum(1 for r in rows if r[3] in ("queued", "approved"))
        await update.message.reply_text(f"Mode: {mode}\nQueued items: {queued}")

    async def cmd_generate(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not context.args:
            await update.message.reply_text("Usage: /generate <prompt>")
            return
        prompt = " ".join(context.args)
        msg = await update.message.reply_text(f"Generating image for: {prompt} ...")
        try:
            image_url = generate_image_pollinations(prompt)
            caption = generate_caption_openrouter(prompt)
            post_id = add_post(image_url, caption, status="queued")
            keyboard = InlineKeyboardMarkup([[
                InlineKeyboardButton("Approve", callback_data=f"approve:{post_id}"),
                InlineKeyboardButton("Reject", callback_data=f"reject:{post_id}"),
                InlineKeyboardButton("Post Now", callback_data=f"postnow:{post_id}")
            ]])
            await update.message.reply_photo(photo=image_url, caption=f"ID: {post_id}\nCaption preview:\n{caption}", reply_markup=keyboard)
        except Exception:
            logger.exception("Generation failed")
            await update.message.reply_text("Generation failed. See logs.")

    async def callback_query(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data
        action, post_id = data.split(":")
        post_id = int(post_id)
        if action == "approve":
            update_status(post_id, "approved")
            await query.edit_message_caption(caption="Approved ✅")
            await query.message.reply_text(f"Post {post_id} approved.")
        elif action == "reject":
            update_status(post_id, "failed")
            await query.edit_message_text(text="Rejected ❌")
        elif action == "postnow":
            update_status(post_id, "approved")
            await query.message.reply_text("Posting now...")
            await self._post_next_approved(context)

    async def cmd_list(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        rows = list_posts()
        if not rows:
            await update.message.reply_text("Queue empty.")
            return
        text = []
        for r in rows[:20]:
            text.append(f"ID:{r[0]} status:{r[3]} created:{r[4]}")
        await update.message.reply_text("\n".join(text))

    async def cmd_postnow(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text("Posting next approved item...")
        try:
            res = await self._post_next_approved(context)
            if res:
                await update.message.reply_text("Posted successfully.")
            else:
                await update.message.reply_text("No approved items in queue.")
        except Exception:
            logger.exception("Post now failed")
            await update.message.reply_text("Posting failed. See logs.")

    async def _post_next_approved(self, context: ContextTypes.DEFAULT_TYPE):
        item = get_next_approved()
        if not item:
            return False
        post_id = item["id"]
        image_url = item["image_url"]
        caption = item["caption"]
        try:
            instagram_res = self.instagram.upload_image_url(image_url, caption)
            update_status(post_id, "posted")
            await context.bot.send_message(chat_id=context._chat_id, text=f"Posted ID {post_id} successfully.")
            return True
        except Exception:
            update_status(post_id, "failed")
            logger.exception("Posting failed")
            return False

    async def cmd_startbot(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if self.auto_task and not self.auto_task.done():
            await update.message.reply_text("Bot is already running.")
            return
        await update.message.reply_text("Starting background auto-posting loop.")
        self.auto_task = asyncio.create_task(self.auto_post_loop(context, update.effective_chat.id))

    async def cmd_stopbot(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if self.auto_task:
            self.auto_task.cancel()
            self.auto_task = None
            await update.message.reply_text("Auto-posting stopped.")
        else:
            await update.message.reply_text("Bot was not running.")

    async def auto_post_loop(self, context: ContextTypes.DEFAULT_TYPE, chat_id:int):
        interval = Config.AUTO_POST_INTERVAL_MINUTES * 60
        await context.bot.send_message(chat_id=chat_id, text=f"Auto-post loop started; interval {Config.AUTO_POST_INTERVAL_MINUTES} minutes.")
        try:
            while True:
                item = get_next_approved()
                if item:
                    try:
                        self.instagram.upload_image_url(item["image_url"], item["caption"])
                        update_status(item["id"], "posted")
                        await context.bot.send_message(chat_id=chat_id, text=f"Auto-posted ID {item['id']}")
                    except Exception:
                        update_status(item["id"], "failed")
                        await context.bot.send_message(chat_id=chat_id, text=f"Auto-post failed for ID {item['id']}")
                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            await context.bot.send_message(chat_id=chat_id, text="Auto-post loop cancelled.")
            return

    def run(self):
        logger.info("Starting Telegram bot...")
        self.app.run_polling()
